import 'package:flutter/material.dart';

void main() => runApp(Hamza96Game());

class Hamza96Game extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(debugShowCheckedModeBanner: false, home: QuizPage());
  }
}

class Question {
  String text;
  List<String> options;
  int answerIndex;
  String image;
  Question(this.text, this.options, this.answerIndex, this.image);
}

class QuizPage extends StatefulWidget {
  @override
  _QuizPageState createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  int current = 0;
  String message = "";
  bool started = false;
  bool showPicker = false;

  List<String> players = [
    "احمد",
    "عمار",
    "غسان",
    "امي",
    "ابوي",
    "لمياء",
    "رفا",
    "دينا"
  ];
  Map<String, int> playerScores = {
    "احمد": 0,
    "عمار": 0,
    "غسان": 0,
    "امي": 0,
    "ابوي": 0,
    "لمياء": 0,
    "رفا": 0,
    "دينا": 0,
  };

  List<Question> questions = [
    Question("في أي عام هجري تم توحيد المملكة؟",
        ["1351 هـ", "1345 هـ", "1355 هـ"], 0, "assets/quiz2.png"),
    Question("كم عدد محافظات المملكة؟",
        ["136 محافظة", "118 محافظة", "150 محافظة"], 0, "assets/quiz2.png"),
    Question("أول بئر نفط؟", ["بئر الدمام 7", "بئر بقيق 1", "بئر الظهران 3"], 0,
        "assets/quiz2.png"),
    Question("معاهدة دارين سنة كم؟", ["1915م", "1927م", "1932م"], 0,
        "assets/quiz2.png"),
    Question("الاسم القديم للرياض؟", ["حجر اليمامة", "الدرعية", "اليمامة"], 0,
        "assets/quiz2.png"),
    Question("مساحة السعودية؟", ["2.15 مليون كم²", "1.5 مليون", "3 مليون"], 0,
        "assets/quiz2.png"),
    Question("أطول جبل؟", ["جبل السودة", "جبل اللوز", "جبل طويق"], 0,
        "assets/quiz2.png"),
    Question("متى تأسست الدرعية؟", ["1446م", "1500م", "1727م"], 0,
        "assets/quiz2.png"),
    Question("كم عدد الملوك؟", ["7 ملوك", "6 ملوك", "8 ملوك"], 0,
        "assets/quiz2.png"),
    Question(
        "أول عاصمة؟", ["الدرعية", "الرياض", "حائل"], 0, "assets/quiz2.png"),
    Question(
        "اكتشاف النفط؟", ["1938م", "1932م", "1945م"], 0, "assets/quiz2.png"),
    Question("نيوم أين؟", ["شمال غرب", "شرق", "جنوب"], 0, "assets/quiz2.png"),
    Question("عدد آبار النفط؟", ["أكثر من 5000", "1000", "2000"], 0,
        "assets/quiz2.png"),
    Question("شعار المملكة؟", ["سيفين ونخلة", "صقرين وسيف", "نخلة"], 0,
        "assets/quiz2.png"),
    Question(
        "نظام الحكم؟", ["ملكي", "جمهوري", "برلماني"], 0, "assets/quiz2.png"),
    Question("مدائن صالح؟", ["العلا", "تبوك", "حائل"], 0, "assets/quiz2.png"),
    Question(
        "التوحيد ميلادي؟", ["1932م", "1930م", "1927م"], 0, "assets/quiz2.png"),
  ];

  void answer(int index) {
    if (showPicker) return; // لا يخليه يجاوب مرة ثانية
    if (index == questions[current].answerIndex) {
      setState(() {
        message = "✅ صحيح";
        showPicker = true;
      });
    } else {
      setState(() => message = "❌ خطأ حاول مرة ثانية");
    }
  }

  void pickPlayer(String name) {
    setState(() {
      playerScores[name] = playerScores[name]! + 1;
      showPicker = false;
      message = "";
      if (current < questions.length - 1) {
        current++;
      } else {
        // نهاية اللعبة
        started = false;
        current = 0;
        // نعرض النتائج
        showDialog(
            context: context,
            builder: (_) => AlertDialog(
                  title: Text("نتائج عائلة حمزة 96 🇸🇦"),
                  content: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: playerScores.entries
                          .map((e) => Text("${e.key}: ${e.value} نقطة",
                              style: TextStyle(fontWeight: FontWeight.bold)))
                          .toList()),
                  actions: [
                    TextButton(
                        onPressed: () {
                          setState(() {
                            playerScores.updateAll((k, v) => 0);
                          });
                          Navigator.pop(context);
                        },
                        child: Text("إعادة اللعبة"))
                  ],
                ));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!started) {
      return Scaffold(
        body: Stack(fit: StackFit.expand, children: [
          Image.asset("assets/Startscreen.png",
              fit: BoxFit.cover,
              errorBuilder: (c, e, s) => Container(color: Color(0xFF1B5E20))),
          Positioned(
              bottom: 160,
              left: 0,
              right: 0,
              child: Center(
                  child: ElevatedButton(
                      onPressed: () => setState(() => started = true),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.black,
                          foregroundColor: Colors.white,
                          padding: EdgeInsets.symmetric(
                              horizontal: 60, vertical: 15),
                          shape: StadiumBorder()),
                      child: Text("بدء",
                          style: TextStyle(
                              fontSize: 22, fontWeight: FontWeight.bold))))),
        ]),
      );
    }

    var q = questions[current];
    return Scaffold(
      backgroundColor: Color(0xFFF1F8E9),
      appBar: AppBar(
        title: Text("اليوم الوطني 96"),
        backgroundColor: Color(0xFF1B5E20),
        foregroundColor: Colors.white,
        actions: [
          Padding(
              padding: EdgeInsets.only(left: 10),
              child: Center(
                  child: Text(
                      "احمد:${playerScores['احمد']} | عمار:${playerScores['عمار']}")))
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(children: [
          Wrap(
              spacing: 6,
              children: playerScores.entries
                  .map((e) => Chip(
                      label: Text("${e.key} ${e.value}",
                          style: TextStyle(fontSize: 12)),
                      backgroundColor: Colors.white))
                  .toList()),
          SizedBox(height: 10),
          Container(
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                  color: Colors.red[700],
                  borderRadius: BorderRadius.circular(20)),
              child: Text("صعب - ${current + 1}/${questions.length}",
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold))),
          SizedBox(height: 10),
          ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Image.asset(q.image,
                  height: 150,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (c, e, s) => Container(
                      height: 150,
                      color: Colors.grey[300],
                      child: Icon(Icons.image)))),
          SizedBox(height: 12),
          Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 4)]),
              child: Text(q.text,
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center)),
          SizedBox(height: 12),
          ...List.generate(
              q.options.length,
              (i) => Container(
                  width: double.infinity,
                  margin: EdgeInsets.only(bottom: 8),
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          foregroundColor: Colors.black,
                          padding: EdgeInsets.all(14),
                          side: BorderSide(color: Colors.green)),
                      onPressed: () => answer(i),
                      child: Text(q.options[i])))),
          SizedBox(height: 10),
          Text(message,
              style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: message.contains("صحيح")
                      ? Colors.green[700]
                      : Colors.red)),

          // القائمة الخضرا
          if (showPicker)
            Container(
              margin: EdgeInsets.only(top: 15),
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                  color: Color(0xFF2E7D32),
                  borderRadius: BorderRadius.circular(15)),
              child: Column(children: [
                Text("مين اللي جاوب؟ 👇",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold)),
                SizedBox(height: 10),
                ...players
                    .map((name) => Container(
                          width: double.infinity,
                          margin: EdgeInsets.only(bottom: 8),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.white,
                                foregroundColor: Colors.black),
                            onPressed: () => pickPlayer(name),
                            child: Text(name,
                                style: TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 16)),
                          ),
                        ))
                    .toList(),
              ]),
            ),
        ]),
      ),
    );
  }
}
